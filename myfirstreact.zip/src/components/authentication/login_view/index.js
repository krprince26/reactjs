import React from 'react'
import LoginView from './LoginView'

export default function index() {
    return ( <LoginView />)
}

