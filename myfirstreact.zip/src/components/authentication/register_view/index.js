import React from 'react'
import RegisterView from './RegisterView'

export default function index() {
    return (<RegisterView />)
}
