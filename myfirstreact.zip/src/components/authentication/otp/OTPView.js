import React, { Component } from 'react'
import { Link, Redirect } from 'react-router-dom'
import '../../../css/styleAuthentication.css'



export default class OTPView extends Component {


    state = {
        mobile: '',
        isLoading: false
    }

    changeHandler = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }

    submitHandler = e => {
        e.preventDefault()
        this.setState({
            isLoading:true
        })
    }


    render() {
        const { isLoading, mobile} = this.state

        if (isLoading) {
            return <Redirect to='/verifyotp' />
        }


        return (
        
            <section className="banner">
                <div className="container">
                    <div className="row">
                        <div className="col-md-7 col-sm-6">
                        </div>

                        <div className="col-md-5 col-sm-6">
                            <div className="wrapper align-center">
                                <div className="text-center">
                                    <img src={require("../../../assets/img/logo.png")} width="30%" height="30%" class="center" />
                                    <br></br><br></br>
                                    <h5 className="font-weight">CREATE ACCOUNT</h5>
                                    <hr></hr>
                                </div>

                                <form className='form' onSubmit={this.submitHandler}>
                                    <div className="form-group">
                                        <label for="usr">Mobile Number </label>
                                        <div className="input-group">
                                            <div className="input-group-prepend">
                                                <span className="input-group-text" id="basic-addon1"><i className="fa fa-mobile"></i></span>
                                            </div>
                                            <input type="text" className="form-control" id="ur" placeholder="Enter Mobile Number" 
                                            name='mobile' value={mobile} onChange={this.changeHandler}
                                            />
                                        </div>
                                    </div>

                                    <div className="buttons text-center">
                                        <button className="btn btn-primary" type="submit">SEND OTP</button>
                                    </div>
                                    <div className="midas text-center">
                                        <hr></hr>
                                        <span>Already a Member?<Link to="/login" className="text-primary">Login</Link> </span>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}



