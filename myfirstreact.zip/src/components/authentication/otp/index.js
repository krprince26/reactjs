import React from 'react'
import OTPView from './OTPView'

export default function index() {
    return (<OTPView/>)
}


