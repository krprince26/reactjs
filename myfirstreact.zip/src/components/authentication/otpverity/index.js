import React from 'react'
import VerifyOTPView from './VerifyOTPView'

export default function index() {
    return (<VerifyOTPView />)
}
