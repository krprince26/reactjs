import React from 'react'
import NavBar from '../menu/NavBar'



export default function index() {
    return (
        <div>
            <NavBar />
            <div className="mt-5 pt-5" style={divStyle}></div>
        </div>
    )
}

const imgMyimageexample = require('../../assets/img/dash.PNG');
const divStyle = {
    width: '100%',
    height: '550px',
    backgroundImage: `url(${imgMyimageexample})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'noRepeat',
};

