import React from 'react'
import '../../css/menu.css'

import logo from '../../assets/img/logo.png'
import avatar from '../../assets/img/avatar.png'
import { NavLink } from 'react-router-dom'


export default function Menu() {
    return (
        <nav className="navbar navbar-expand-sm navbar-dark fixed-top">
            <a href="/" className="navbar-brand">
                <img src={logo} alt="" height='50' width='50' /> Winds Partner</a>
            <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#myMenu">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="myMenu">
                <ul className="navbar-nav ml-auto custom-nav">
                    <li className="dropdown dropdown-user nav-item">
                    <a className="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown" aria-expanded="false">
                        
                        <span class="avatar avatar-online"><img src={avatar} /> </span>
                        <span class="user-name">John Doe</span></a>
                   
                    <div className="dropdown-menu dropdown-menu-right"><a className="dropdown-item" href="user-profile.html"><i className="ft-user"></i> Edit Profile</a><a className="dropdown-item" href="app-email.html"><i className="ft-mail"></i> My Inbox</a><a className="dropdown-item" href="user-cards.html"><i className="ft-check-square"></i> Task</a><a className="dropdown-item" href="app-chat.html"><i className="ft-message-square"></i> Chats</a>
                  <div className="dropdown-divider"></div><a className="dropdown-item" href="login-with-bg-image.html"><i className="ft-power"></i> Logout</a>
                </div>
                   </li>
                </ul>
            </div>
        </nav>
    )
}
